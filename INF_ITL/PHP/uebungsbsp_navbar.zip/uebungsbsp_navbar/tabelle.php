<?php
echo '<h1>Tabellen mit HTML</h1>';